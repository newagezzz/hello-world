package jp.co.nri.BoxBoot.common;

import java.time.LocalDate;
import java.time.LocalDateTime;  
import java.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BoxCommon {

	protected static final long CNT_LARGE_FILE_SIZE = 50000000;
    protected static Logger logger = LoggerFactory.getLogger("jp.co.nri.BoxBoot.BoxAccess.Log");
    protected static Logger result = LoggerFactory.getLogger("jp.co.nri.BoxBoot.BoxAccess.Rst");
	protected static DateTimeFormatter dtFmtYmdhms =  DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
	protected static DateTimeFormatter dtFmtYmdhmsX =  DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
	protected static DateTimeFormatter dtFmtYmd =  DateTimeFormatter.ofPattern("yyyyMMdd");
	protected static DateTimeFormatter dtFmtYmdX =  DateTimeFormatter.ofPattern("yyyy/MM/dd");
    protected static LocalDate todayDate = LocalDate.now();
    protected static String todayStrg = dtFmtYmdX.format(todayDate);

	protected static long currTimer;

	protected static void testLoggingLevel() {
		logger.trace("Test logging level:trace");
		logger.debug("Test logging level:debug");
		logger.info("Test logging level:info");
		logger.warn("Test logging level:warn");
		logger.error("Test logging level:error");
	}

	protected static void startTimer() {
		currTimer = System.currentTimeMillis();
	}
	protected static long timerValue() {
		long endTimer = System.currentTimeMillis();
		return endTimer - currTimer;
	}

	protected static void disp(String msg) {
        // 現在日時を取得
        LocalDateTime nowDate = LocalDateTime.now();
		System.out.println(nowDate + ":[" + msg + "]");
	}
	protected static String nowStr() {
		return nowStr(false);
	}

	protected static String nowStr(boolean sep) {
        LocalDateTime nowDate = LocalDateTime.now();
		if (sep) { 
			return dtFmtYmdhmsX.format(nowDate); 
		} else {
			return dtFmtYmdhms.format(nowDate); 
		}
	}
}
