package jp.co.nri.BoxBoot;

import java.util.ArrayList;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import jp.co.nri.BoxBoot.common.BoxCommon;
import jp.co.nri.BoxBoot.service.CommonService;
import jp.co.nri.BoxBoot.service.BoxAccessService;
import jp.co.nri.BoxBoot.service.WebAccessService;
import jp.co.nri.BoxBoot.service.NonAccessService;
import jp.co.nri.BoxBoot.service.BoxFldeltService;
import jp.co.nri.BoxBoot.service.BoxFldlstService;

@SpringBootApplication
public class BoxBootApplication extends BoxCommon {
	public static void main(String[] args) {
		CommonService svc;
		boolean useProxy = false;
		String accType = "NONACCESS";
		String authType = "JWT";
		ArrayList<String> strList = new ArrayList<String>();
		try {
 		    ConfigurableApplicationContext ctx = SpringApplication.run(BoxBootApplication.class, args);
			logger.info("main function: start...");
			testLoggingLevel();
			for (int idx = 0; idx < args.length; idx++) {
				switch(args[idx].toUpperCase()) {
					case "USEPROXY":
						useProxy = true;
						break;
					case "NONPROXY":
						useProxy = false;
						break;
					case "JWT":
						authType = "JWT";
						break;
					case "OAUTH2":
						authType = "OAUTH2";
						break;
					case "BOXACCESS":
						accType = "BOXACCESS";
						break;
					case "WEBACCESS":
						accType = "WEBACCESS";
						break;
					case "NONACCESS":
						accType = "NONACCESS";
						break;
					case "BOXFLDELT":
						accType = "BOXFLDELT";
						break;
					case "BOXFLDLST":
						accType = "BOXFLDLST";
						break;
					default:
						strList.add(args[idx]);
						break;
				}
			}
			switch(accType) {
				case "BOXACCESS":
					svc = ctx.getBean(BoxAccessService.class);
					break;
				case "WEBACCESS":
					svc = ctx.getBean(WebAccessService.class);
					break;
				case "NONACCESS":
					svc = ctx.getBean(NonAccessService.class);
					break;
				case "BOXFLDELT":
					svc = ctx.getBean(BoxFldeltService.class);
					break;
				case "BOXFLDLST":
					svc = ctx.getBean(BoxFldlstService.class);
					break;
				default:
					svc = ctx.getBean(NonAccessService.class);
					break;
			}
		    svc.run(useProxy, authType, strList.toArray(new String[0]));
		    logger.info("main function: finish...");
		} catch (Exception ex) {
			logger.error("Exception occurred:[" + ex + "]!");
			ex.printStackTrace();  // スタックトレースを出力する
		}
	}
}
