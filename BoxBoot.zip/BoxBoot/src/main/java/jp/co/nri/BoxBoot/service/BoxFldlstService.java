package jp.co.nri.BoxBoot.service;

import java.io.IOException;
import java.io.Reader;
import java.io.FileReader;
import java.io.FileInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.net.Proxy;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.net.Authenticator;
import java.net.PasswordAuthentication;
import java.util.Scanner;
import com.box.sdk.BoxConfig;
import com.box.sdk.BoxDeveloperEditionAPIConnection;
import com.box.sdk.BoxAPIConnection;
import com.box.sdk.BoxFolder;
import com.box.sdk.BoxFile;
import com.box.sdk.BoxItem;
import com.box.sdk.BoxLogger;
import com.box.sdk.BoxUser;
import com.box.sdk.DeveloperEditionEntityType;
import com.box.sdk.IAccessTokenCache;
import com.box.sdk.InMemoryLRUAccessTokenCache;
import com.box.sdk.BoxAPIResponseException;
import com.box.sdk.BoxAPIException;
import jp.co.nri.BoxBoot.common.Upload;
import jp.co.nri.BoxBoot.common.UploadSetting;
import jp.co.nri.BoxBoot.common.UploadPlan;

import org.springframework.stereotype.Service;

@Service
public class BoxFldlstService extends CommonService {

    static IAccessTokenCache accessTokenCache = new InMemoryLRUAccessTokenCache(100);
	static  String entityID;
    static  DeveloperEditionEntityType entityType;
	
	public void run(boolean useProxy, String authType, String[] args) {
		logger.info("BoxFldlstService run function: start...");
		BoxAPIConnection api = null; 
		try {
			super.startRun(useProxy, args);
			if (authType.equals("OAUTH2")) {
				String authCode;
				//Authenticate code in parameter
				if (args.length > 0) {
					authCode = args[0];
				} else {
					Scanner in = new Scanner(System.in);
					System.out.println("Please enter authenticate code:");
					authCode = in.next();
				}
				logger.debug("clientId:["+ 	boxOAuth2ClientId + "],clientSecret:[" + boxOAuth2ClientSecret + "], authenticateCode:[" + authCode + "]");
				api = new BoxAPIConnection(boxOAuth2ClientId, boxOAuth2ClientSecret);
				if (useProxy) {
					api.setProxy(proxy);											
				}
				api.authenticate(authCode);											
			} else {
				Reader reader = new FileReader(boxAuthJwtFile);
				BoxConfig boxConfig = BoxConfig.readFrom(reader);
				String enterpriseId = boxConfig.getEnterpriseId();
				logger.info(String.format("Enterprise id...[%s]", enterpriseId));
				api = new BoxDeveloperEditionAPIConnection(enterpriseId, 
					DeveloperEditionEntityType.ENTERPRISE, boxConfig, accessTokenCache);
				if (useProxy) {
					api.setProxy(proxy);											
				}
				((BoxDeveloperEditionAPIConnection)api).authenticate();											
			}
			BoxUser user = BoxUser.getCurrentUser(api);
			BoxUser.Info userInfo = user.getInfo();
			logger.info("userInfo : "+ userInfo.getName());
			logger.info(String.format("Box Folder List task [%s] start......\n", upload.taskName));
			//do folder initialization
			boolean ret = doListing(api, upload);
			logger.info("doListing result:["+ ret + "]");

			super.finishRun();
		} catch (Exception ex) {
			logger.error("Exception occurred:[" + ex + "]!");
			ex.printStackTrace(); 
		}
		logger.info("BoxFldlstService run function: finish...");
	}

	boolean doListing(BoxAPIConnection api, Upload upload) {
		logger.info("BoxFldlstService.doListing start......");
		boolean ret;
		for (UploadSetting us :upload.uploadSettings) {
			logger.info(String.format("    LocalDocDir:[%s],BoxFolderId:[%s]", us.localDocDir, us.boxFolderId));
			BoxFolder folder;
			BoxFolder subFolder;
			BoxFolder.Info folderInfo;
			BoxFile.Info fileInfo = null;
			BoxFile file = null;
			Iterable<BoxItem.Info> fldItems = null;
			try {
				folder = new BoxFolder(api, us.boxFolderId);
				folderInfo = folder.getInfo();
				logger.info(String.format("Box Folder ID:[%s], Name:[%s]\n", folderInfo.getID(), folderInfo.getName()));
				recResult(String.format("%sBox Folder[%s]", "-".repeat(0 * 4), folderInfo.getName()));
				//フォルダ配下ファイル・サブフォルダリスティング
				doListingSub(folder, 1);
			} catch (Exception ex) {
				logger.info(String.format("------------------BOXフォルダーリスティングエラー,[%s]", ex));
			}
		}
		logger.info("BoxFldlstService.doListing finish...");
		return true;
	}

	void doListingSub(BoxFolder folder, int lvl) {
		logger.info("BoxFldlstService.doListingSub start......");
		BoxFolder subFolder;
		Iterable<BoxItem.Info> fldItems = null;
		//フォルダ配下ファイル・サブフォルダリスティング
		fldItems = folder.getChildren();
		for (BoxItem.Info bi : fldItems) {
			if ("file".equals(bi.getType())) {
				logger.info(String.format("------------------Box File Name:[%s]", bi.getName()));
				recResult(String.format("%sBox File[%s]", "-".repeat(lvl * 4), bi.getName()));
			}
		}

		for (BoxItem.Info bi : fldItems) {
			if ("folder".equals(bi.getType())) {
				logger.info(String.format("------------------Box Folder Name:[%s]", bi.getName()));
				recResult(String.format("%sBox Folder[%s]", "-".repeat(lvl * 4), bi.getName()));
				subFolder = ((BoxFolder.Info)bi).getResource();
				doListingSub(subFolder, lvl + 1);
			}
		}
		return;
	}
}
