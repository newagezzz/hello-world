package jp.co.nri.BoxBoot.common;

import java.time.LocalDate;
import java.util.List;

public class UploadSetting { 
    public String localDocDir; 
    public String boxFolderId; 
    public String uploadDate; 
    public List<UploadPlan> uploadPlans; 
    //getter, setter 
    public void setLocalDocDir(String localDocDir) {
      this.localDocDir = localDocDir;
    }
    public String getLocalDocDir() {
      return this.localDocDir;
    }
    public void setBoxFolderId(String boxFolderId) {
      this.boxFolderId = boxFolderId;
    }
    public String getBoxFolderId() {
      return this.boxFolderId;
    }
    public void setUploadDate(String uploadDate) {
        this.uploadDate = uploadDate;
    }
    public String getUploadDate() {
        return this.uploadDate;
    }
    public void setUploadPlans(List<UploadPlan> uploadPlans) {
      this.uploadPlans = uploadPlans;
    }
    public List<UploadPlan> getUploadPlans() {
      return this.uploadPlans;
    }
    public boolean chkUploadToday(String todayStrg, boolean uploadTodayOnly) {
        if (!uploadTodayOnly) {
            return true;
        }
        if (todayStrg.equals(uploadDate) || "9999/99/99".equals(uploadDate)) {
            return true;
        }
			  for (UploadPlan up :uploadPlans) {
            if (todayStrg.equals(up.getUploadDate()) || "9999/99/99".equals(up.getUploadDate())) {
                return true;
            }
        }
        return false;
    }
}
