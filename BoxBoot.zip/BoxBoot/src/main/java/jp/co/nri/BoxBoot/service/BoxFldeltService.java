package jp.co.nri.BoxBoot.service;

import java.io.IOException;
import java.io.Reader;
import java.io.FileReader;
import java.io.FileInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.net.Proxy;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.net.Authenticator;
import java.net.PasswordAuthentication;
import java.util.Scanner;
import com.box.sdk.BoxConfig;
import com.box.sdk.BoxDeveloperEditionAPIConnection;
import com.box.sdk.BoxAPIConnection;
import com.box.sdk.BoxFolder;
import com.box.sdk.BoxFile;
import com.box.sdk.BoxItem;
import com.box.sdk.BoxLogger;
import com.box.sdk.BoxUser;
import com.box.sdk.DeveloperEditionEntityType;
import com.box.sdk.IAccessTokenCache;
import com.box.sdk.InMemoryLRUAccessTokenCache;
import com.box.sdk.BoxAPIResponseException;
import com.box.sdk.BoxAPIException;
import jp.co.nri.BoxBoot.common.Upload;
import jp.co.nri.BoxBoot.common.UploadSetting;
import jp.co.nri.BoxBoot.common.UploadPlan;

import org.springframework.stereotype.Service;

@Service
public class BoxFldeltService extends CommonService {

    static IAccessTokenCache accessTokenCache = new InMemoryLRUAccessTokenCache(100);
	static  String entityID;
    static  DeveloperEditionEntityType entityType;
	
	public void run(boolean useProxy, String authType, String[] args) {
		logger.info("BoxFldeltService run function: start...");
		BoxAPIConnection api = null; 
		try {
			super.startRun(useProxy, args);
			if (authType.equals("OAUTH2")) {
				String authCode;
				//Authenticate code in parameter
				if (args.length > 0) {
					authCode = args[0];
				} else {
					Scanner in = new Scanner(System.in);
					System.out.println("Please enter authenticate code:");
					authCode = in.next();
				}
				logger.debug("clientId:["+ 	boxOAuth2ClientId + "],clientSecret:[" + boxOAuth2ClientSecret + "], authenticateCode:[" + authCode + "]");
				api = new BoxAPIConnection(boxOAuth2ClientId, boxOAuth2ClientSecret);
				if (useProxy) {
					api.setProxy(proxy);											
				}
				api.authenticate(authCode);											
			} else {
				Reader reader = new FileReader(boxAuthJwtFile);
				BoxConfig boxConfig = BoxConfig.readFrom(reader);
				String enterpriseId = boxConfig.getEnterpriseId();
				logger.info(String.format("Enterprise id...[%s]", enterpriseId));
				api = new BoxDeveloperEditionAPIConnection(enterpriseId, 
					DeveloperEditionEntityType.ENTERPRISE, boxConfig, accessTokenCache);
				if (useProxy) {
					api.setProxy(proxy);											
				}
				((BoxDeveloperEditionAPIConnection)api).authenticate();											
			}
			BoxUser user = BoxUser.getCurrentUser(api);
			BoxUser.Info userInfo = user.getInfo();
			logger.info("userInfo : "+ userInfo.getName());
			logger.info(String.format("Box Folder Initialization task [%s] start......\n", upload.taskName));
			//do folder initialization
			boolean ret = doInitialize(api, upload);
			logger.info("doInitialize result:["+ ret + "]");

			super.finishRun();
		} catch (Exception ex) {
			logger.error("Exception occurred:[" + ex + "]!");
			ex.printStackTrace(); 
		}
		logger.info("BoxFldeltService run function: finish...");
	}

	boolean doInitialize(BoxAPIConnection api, Upload upload) {
		logger.info("BoxFldeltService.doInitialize start......");
		boolean ret;
		for (UploadSetting us :upload.uploadSettings) {
			logger.info(String.format("    LocalDocDir:[%s],BoxFolderId:[%s]", us.localDocDir, us.boxFolderId));
			BoxFolder folder;
			BoxFolder subFolder;
			BoxFolder.Info folderInfo;
			BoxFile.Info fileInfo = null;
			BoxFile file = null;
			Iterable<BoxItem.Info> fldItems = null;
			try {
				folder = new BoxFolder(api, us.boxFolderId);
				folderInfo = folder.getInfo();
				logger.info(String.format("Box Folder ID:[%s], Name:[%s]\n", folderInfo.getID(), folderInfo.getName()));
				//フォルダ配下ファイル・サブフォルダアップロード
				fldItems = folder.getChildren();
				for (BoxItem.Info bi : fldItems) {
					logger.info(String.format("BoxItem.Info Type:[%s], Name:[%s]", bi.getType(), bi.getName()));
					switch(bi.getType()) {
						case "folder":
							subFolder = ((BoxFolder.Info)bi).getResource();
							subFolder.delete(true);
							break;
						case "file":
							file = ((BoxFile.Info)bi).getResource();
							file.delete();
							break;
					}
				}
			} catch (Exception ex) {
				logger.info(String.format("------------------BOXフォルダー初期化エラー,[%s]", ex));
			}
		}
		logger.info("BoxFldeltService.doInitialize finish...");
		return true;
	}
}
