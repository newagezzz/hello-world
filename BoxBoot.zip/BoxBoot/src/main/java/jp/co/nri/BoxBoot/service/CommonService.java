package jp.co.nri.BoxBoot.service;

import java.net.Proxy;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.net.Authenticator;
import java.net.PasswordAuthentication;

import java.nio.file.Paths;
import java.nio.file.Path;
import java.nio.file.Files;
import com.fasterxml.jackson.databind.ObjectMapper; 
import com.fasterxml.jackson.databind.SerializationFeature;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.beans.factory.annotation.Value;
import jp.co.nri.BoxBoot.common.BoxCommon;
import jp.co.nri.BoxBoot.common.Upload;

public abstract class CommonService extends BoxCommon {

	@Value("${proxy.host:}")
	protected String proxyHost;
	@Value("${proxy.port:}")
	protected String proxyPort;
	@Value("${proxy.user:}")
	protected String proxyUser;
	@Value("${proxy.password:}")
	protected String proxyPassword;
	@Value("${box.auth.jwt.file:}")
	protected String boxAuthJwtFile;
	@Value("${box.upload.today.only}")
	protected boolean boxUploadTodayOnly;
	@Value("${box.upload.file.ext:}")
	protected String boxUploadFileExt;
	@Value("${box.upload.setting.file}")
	protected String boxUploadSettingFile;
	@Value("${box.upload.result.file}")
	protected String boxUploadResultFile;
	@Value("${box.folder.exist.proc}")
	protected String boxFolderExistProc;
	@Value("${box.file.exist.proc}")
	protected String boxFileExistProc;
	@Value("${box.oauth2.client.id:}")
	protected String boxOAuth2ClientId;
	@Value("${box.oauth2.client.secret:}")
	protected String boxOAuth2ClientSecret;

	Proxy proxy = null;
	Upload upload = null; 

	public abstract void run(boolean useProxy, String authType, String[] agrs) throws Exception;

	protected void startRun(boolean useProxy, String[] agrs) throws Exception {
		logger.info("CommonService run function: start...");
		logger.info(String.format("Environments Variable, Proxy host:[%s], port:[%s], user:[%s], password:[%s]", proxyHost, proxyPort, proxyUser, proxyPassword));
		logger.info(String.format("Environments Variable, Box authenticate Jwt file:[%s]", boxAuthJwtFile));
		logger.info(String.format("Environments Variable, Box upload today only:[%s]", boxUploadTodayOnly));
		logger.info(String.format("Environments Variable, Box upload file extensions:[%s]", boxUploadFileExt));
		logger.info(String.format("Environments Variable, Box upload setting file:[%s]", boxUploadSettingFile));
		logger.info(String.format("Environments Variable, Box upload result file:[%s]", boxUploadResultFile));
		logger.info(String.format("Environments Variable, Box folder exist proc:[%s]", boxFolderExistProc));
		logger.info(String.format("Environments Variable, Box file exist proc:[%s]", boxFileExistProc));
		logger.info(String.format("Environments Variable, Box OAuth2 client id:[%s]", boxOAuth2ClientId));
		logger.info(String.format("Environments Variable, Box OAuth2 client secret:[%s]", boxOAuth2ClientSecret));

		if (useProxy) {
			try {
				proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(InetAddress.getByAddress(strToIp(proxyHost)), Integer.parseInt(proxyPort)));
			} catch (UnknownHostException e) {
				e.printStackTrace();
				throw e;
			}
			Authenticator.setDefault(new Authenticator() {
					protected PasswordAuthentication getPasswordAuthentication() {
							return new PasswordAuthentication(proxyUser, proxyPassword.toCharArray());
					}
			});				
		}
		//Json to Upload Class 
		Path file = Paths.get(boxUploadSettingFile);
		String jsonStr = Files.readString(file);
		ObjectMapper mapper = new ObjectMapper();   
		upload = mapper.readValue(jsonStr, Upload.class); 
		mapper.enable(SerializationFeature.INDENT_OUTPUT);
		logger.info("Upload to String:[" + upload.toString() + "]");
		logger.info("Upload to Json:[" + mapper.writeValueAsString(upload) + "]");
		logger.info("CommonService run function: finish...");

		//Upload result logging start....
		recResult(String.format("↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓Start of upload result↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓"));
		recResult(String.format("Start time:[%s]", nowStr(true)));
		recResult(String.format("Upload plan↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓"));
		recResult(String.format(jsonStr));
		recResult(String.format("Upload plan↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑"));
	}

	protected void finishRun() throws Exception {
		//Upload result logging start....
		recResult(String.format("Finish time:[%s]", nowStr(true)));
		recResult(String.format("↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑Finish of upload result↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑"));
	}

	protected void recResult(String msg){
		result.info(msg);
	}

	protected byte[] strToIp(String ipStr){
		byte[] arrByte = new byte[4];
		String[] arrStr = ipStr.split("\\.");
		for (int i=0; i<=3; i++) { 
			arrByte[i] = (byte)Integer.parseInt(arrStr[i]);
		}
		return arrByte;
	}

    /** MD2アルゴリズム */
    protected static final String MD2 = "MD2";
    /** MD5アルゴリズム */
    protected static final String MD5 = "MD5";
    /** SHA-1アルゴリズム */
    protected static final String SHA_1 = "SHA-1";
    /** SHA-256アルゴリズム */
    protected static final String SHA_256 = "SHA-256";
    /** SHA-512アルゴリズム */
    protected static final String SHA_512 = "SHA-512";

    /**
     * ファイルのSHA-1ハッシュ値（文字列）を返す
     * @param filePath ファイルパス
     * @return SHA-1ハッシュ値（文字列）
     */
    protected static String getFileSha1Hash(String filePath) {
		return getFileHash(filePath, SHA_1);
	}

    /**
     * ファイルのハッシュ値（文字列）を返す
     * @param filePath ファイルパス
     * @param algorithmName アルゴリズム
     * @return ハッシュ値（文字列）
     */
    protected static String getFileHash(String filePath, String algorithmName) {

        Path path = Paths.get(filePath);

        byte[] hash = null;

        // アルゴリズム取得
        MessageDigest md = null;
        try {
            md = MessageDigest.getInstance(algorithmName);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        try (
                // 入力ストリームの生成
            DigestInputStream dis = new DigestInputStream(
                new BufferedInputStream(Files.newInputStream(path)), md)) {

            // ファイルの読み込み
            while (dis.read() != -1) {
            }

            // ハッシュ値の計算
            hash = md.digest();

        } catch (IOException e) {
            e.printStackTrace();
        }

        // ハッシュ値（byte）を文字列に変換し返却
        StringBuilder sb = new StringBuilder();
        for (byte b : hash) {
            String hex = String.format("%02x", b);
            sb.append(hex);
        }
        return sb.toString();
    }

}
