package jp.co.nri.BoxBoot.service;

import org.springframework.stereotype.Service;

@Service
public class NonAccessService extends CommonService {

	public void run(boolean useProxy, String authType, String[] args) {

		logger.info("NonAccessService run function: start...");
		logger.info("do nothing........................");
		logger.info("NonAccessService run function: finish...");
	}
}
