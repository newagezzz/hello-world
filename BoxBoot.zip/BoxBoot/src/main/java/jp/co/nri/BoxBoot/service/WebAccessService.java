package jp.co.nri.BoxBoot.service;

import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.HttpURLConnection;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;

import org.springframework.stereotype.Service;

@Service
public class WebAccessService extends CommonService {

	public void run(boolean useProxy, String authType, String[] args) {

		String urlStr;
		String urlGoole = "https://www.google.com/";
		logger.info("WebAccessService run function: start...");
		try {
			super.startRun(useProxy, args);
			TrustManager[] tm = {
					new X509TrustManager() {
							public X509Certificate[] getAcceptedIssuers() {
							return null;
							}
							public void checkClientTrusted(X509Certificate[] xc,String type) {
							}
							public void checkServerTrusted(X509Certificate[] xc,String type) {
							}
					}
			};
			SSLContext ctx = SSLContext.getInstance("SSL");
			ctx.init(null, tm, new SecureRandom());

			if (args.length > 0) {
				urlStr = args[0];
			} else {
				urlStr = urlGoole;
			}
			logger.info(String.format("get response from url:[%s]", urlStr));
			URL url = new URL(urlStr);
			//HttpURLConnection connection;
			HttpsURLConnection connection;
			if (useProxy) {
			    //connection = (HttpURLConnection) url.openConnection(proxy);
                connection = (HttpsURLConnection) url.openConnection(proxy);
			} else {
			    //connection = (HttpURLConnection) url.openConnection();
                connection = (HttpsURLConnection) url.openConnection();
			}
			connection.setDoOutput(true);
			connection.setSSLSocketFactory(ctx.getSocketFactory());
			connection.setRequestMethod("GET");
			connection.connect();
			logger.info("after connection......");
			logger.info("Response Code/Message:[" + connection.getResponseCode() + "/" + connection.getResponseMessage() + "]");

			try (BufferedReader in = new BufferedReader(
				new InputStreamReader(connection.getInputStream())))
			{
				String line;
				logger.info("↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓:Response of [" + urlStr + "]");
				while ((line = in.readLine()) != null) {
					logger.info(line);
				}
				logger.info("↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑:Response of [" + urlStr + "]");
			}
			super.finishRun();
		} catch (Exception ex) {
			logger.error("Exception occurred:[" + ex + "]!");
			ex.printStackTrace();  // スタックトレースを出力する
		}
		logger.info("WebAccessService run function: finish...");
	}
}
