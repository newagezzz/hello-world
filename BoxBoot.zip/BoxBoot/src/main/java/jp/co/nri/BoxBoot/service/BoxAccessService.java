package jp.co.nri.BoxBoot.service;

import java.io.IOException;
import java.io.Reader;
import java.io.FileReader;
import java.io.FileInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.net.Proxy;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.net.Authenticator;
import java.net.PasswordAuthentication;
import java.util.Scanner;
import com.box.sdk.BoxConfig;
import com.box.sdk.BoxDeveloperEditionAPIConnection;
import com.box.sdk.BoxAPIConnection;
import com.box.sdk.BoxFolder;
import com.box.sdk.BoxFile;
import com.box.sdk.BoxItem;
import com.box.sdk.BoxLogger;
import com.box.sdk.BoxUser;
import com.box.sdk.DeveloperEditionEntityType;
import com.box.sdk.IAccessTokenCache;
import com.box.sdk.InMemoryLRUAccessTokenCache;
import com.box.sdk.BoxAPIResponseException;
import com.box.sdk.BoxAPIException;
import jp.co.nri.BoxBoot.common.Upload;
import jp.co.nri.BoxBoot.common.UploadSetting;
import jp.co.nri.BoxBoot.common.UploadPlan;

import org.springframework.stereotype.Service;

@Service
public class BoxAccessService extends CommonService {

    static IAccessTokenCache accessTokenCache = new InMemoryLRUAccessTokenCache(100);
	static  String entityID;
    static  DeveloperEditionEntityType entityType;
	
	public void run(boolean useProxy, String authType, String[] args) {
		logger.info("BoxAccessService run function: start...");
		BoxAPIConnection api = null; 
		try {
			super.startRun(useProxy, args);
			if (authType.equals("OAUTH2")) {
				String authCode;
				//Authenticate code in parameter
				if (args.length > 0) {
					authCode = args[0];
				} else {
					Scanner in = new Scanner(System.in);
					System.out.println("Please enter authenticate code:");
					authCode = in.next();
				}
				logger.debug("clientId:["+ 	boxOAuth2ClientId + "],clientSecret:[" + boxOAuth2ClientSecret + "], authenticateCode:[" + authCode + "]");
				api = new BoxAPIConnection(boxOAuth2ClientId, boxOAuth2ClientSecret);
				if (useProxy) {
					api.setProxy(proxy);											
				}
				api.authenticate(authCode);											
			} else {
				Reader reader = new FileReader(boxAuthJwtFile);
				BoxConfig boxConfig = BoxConfig.readFrom(reader);
				String enterpriseId = boxConfig.getEnterpriseId();
				logger.info(String.format("Enterprise id...[%s]", enterpriseId));
				api = new BoxDeveloperEditionAPIConnection(enterpriseId, 
					DeveloperEditionEntityType.ENTERPRISE, boxConfig, accessTokenCache);
				if (useProxy) {
					api.setProxy(proxy);											
				}
				((BoxDeveloperEditionAPIConnection)api).authenticate();											
			}
			BoxUser user = BoxUser.getCurrentUser(api);
			BoxUser.Info userInfo = user.getInfo();
			logger.info("userInfo : "+ userInfo.getName());
			logger.info(String.format("Box Upload task [%s] start......\n", upload.taskName));
			//do upload files planned at today or all
			boolean ret = doUpload(api, upload);
			logger.info("doUpload result:["+ ret + "]");

			super.finishRun();
		} catch (Exception ex) {
			logger.error("Exception occurred:[" + ex + "]!");
			ex.printStackTrace(); 
		}
		logger.info("BoxAccessService run function: finish...");
	}

	boolean doUpload(BoxAPIConnection api, Upload upload) {
		logger.info("BoxAccessService.doUpload start......");
		boolean ret;
		for (UploadSetting us :upload.uploadSettings) {
			logger.info(String.format("    LocalDocDir:[%s],BoxFolderId:[%s]", us.localDocDir, us.boxFolderId));
  		    recResult(String.format("LocalDocDir:[%s],BoxFolderId:[%s]", us.localDocDir, us.boxFolderId));
			if (!us.chkUploadToday(todayStrg, boxUploadTodayOnly)) {
				logger.info("------------------本日アップロード対象外");
				recResult("----本日アップロード対象外");
				continue;
			} 
			if (!existInDir(us.localDocDir, "")) {
				logger.info("------------------ローカルディレクトリ存在しない");
				recResult("----ローカルディレクトリ存在しない");
				continue;
			}
			BoxFolder folder;
			BoxFolder subFolder;
			BoxFolder.Info info;
			try {
				folder = new BoxFolder(api, us.boxFolderId);
				info = folder.getInfo();
				logger.info(String.format("Box Folder ID:[%s], Name:[%s]\n", info.getID(), info.getName()));
				//フォルダ配下ファイル・サブフォルダアップロード
				if (todayStrg.equals(us.uploadDate) || "9999/99/99".equals(us.uploadDate)) {
					//Upload all files of sub-directory
					doUploadSubFiles(us.localDocDir, folder, 2);
					//サブフォルダーアップロード計画が無ければ、親フォルダーでアップロード
					if (us.uploadPlans.size() == 0) {
						//Upload all directories of sub-directory
						doUploadSubDirs(us.localDocDir, folder, 2);
					}
				}
				//フォルダ配下サブフォルダアップロード
				for (UploadPlan up :us.uploadPlans) {
					logger.info(String.format("        LocalSubDir:[%s],UploadDate:[%s],UploadToday:[%s]", 
					    up.localSubDir, up.uploadDate, todayStrg.equals(up.uploadDate)));
					recResult(String.format("----LocalSubDir:[%s],UploadDate:[%s]", up.localSubDir, up.uploadDate));
					if (!up.chkUploadToday(todayStrg, boxUploadTodayOnly)) {
						logger.info("----------------------本日アップロード対象外");
						recResult("--------本日アップロード対象外");
						continue;
					}
					if (!existInDir(us.localDocDir, up.localSubDir)) {
						logger.info("----------------------ローカルサブディレクトリ存在しない");
						recResult("--------ローカルサブディレクトリ存在しない");
						continue;
					}
					logger.info("----------------------BOXへアップロード");
					recResult(String.format("--------サブディレクトリー:[%s],BOXアップロード",up.localSubDir));
					subFolder = doUploadSub(us.localDocDir, up.localSubDir, folder, 3);
				}
			} catch (Exception ex) {
				logger.info(String.format("------------------BOXフォルダーアップロードエラー,[%s]", ex));
				recResult("----BOXフォルダーアップロードエラー");
			}
		}
		logger.info("BoxAccessService.doUpload finish...");
		return true;
	}

	BoxFolder doUploadSub(String localDocDir, String localSubDir, BoxFolder folder, int lvl) throws Exception {
		logger.info("BoxAccessService.doUploadSub start......");
		String strDir;
		strDir = localDocDir + "//" + localSubDir;
		logger.info(String.format("Local Directory to upload:[%s]\n", strDir));

		BoxFolder subFolder = null;
		startTimer();
		subFolder = createBoxFolder(folder, localSubDir, lvl);
		logger.info(String.format("------------------BOXフォルダー作成時間:[%,d]ms", timerValue()));
		if (subFolder == null) {
			//フォルダ存在、かつスキップ
			return null;
		}

	    //Upload all files of sub-directory
		doUploadSubFiles(strDir, subFolder, lvl);
	    //Upload all directories of sub-directory
		doUploadSubDirs(strDir, subFolder, lvl);
        // ファイルとフォルダ以外は処理しない

		logger.info("BoxAccessService.doUploadSub finish......");
		return subFolder;
	}

	void doUploadSubFiles(String localDir, BoxFolder subFolder, int lvl) throws Exception {
		logger.info("BoxAccessService.doUploadSubFiles start......");
        File file1 = new File(localDir);
        File fileArray1[] = file1.listFiles();
        for (File f: fileArray1) {
	    	// ファイルのアップロード
            if(f.isFile() && chkUploadFile(f.getName(), boxUploadFileExt)) {
				try {
					//BOXフォルダー存在時、フォルダそのまま利用有るため、ファイル存在のケースもある
					startTimer();
					String fileSha1Hash = getFileSha1Hash(f.toPath().toString());
					logger.info(String.format("------------------ファイルSHA1ハッシュ:[%s], 作成時間:[%,d]ms", fileSha1Hash, timerValue()));
					startTimer();
					long fsize = f.length();
					BoxFile.Info fileInfo;
					FileInputStream input = new FileInputStream(f);
					fileInfo = uploadBoxFile(subFolder, input, f.getName(), fsize, lvl);
					logger.info(String.format("File uploaded, LocalDir:[%s], FileName:[%s], LinkUrl:[%s]",
					    localDir, f.getName(), fileInfo.getPreviewLink()));
					logger.info(String.format("------------------ファイルサイズ:[%,d], アップロード時間:[%,d]ms", fsize, timerValue()));
					startTimer();
					String boxSha1Hash = fileInfo.getSha1();
					logger.info(String.format("------------------ボックスSHA1ハッシュ:[%s], 取得時間:[%,d]ms", boxSha1Hash, timerValue()));
					logger.info(String.format("------------------ボックスSHA1ハッシュ===ファイルSHA1ハッシュ:[%s]", boxSha1Hash.equals(fileSha1Hash)));
					recResult(String.format("%sLocal file[%s] upload succeeded.", "-".repeat(lvl * 4), f.getName()));
				} catch (Exception ex) {
					logger.error(String.format("File upload failed. Local Directory:[%s], File:[%s], Error:[%s]", localDir, f.getName(), ex));
					recResult(String.format("%sLocal file[%s] upload failed.", "-".repeat(lvl * 4), f.getName()));
					throw ex;
				}
            } 
		}
		logger.info("BoxAccessService.doUploadSubFiles finish......");
		return;
	}

	void doUploadSubDirs(String localDir, BoxFolder subFolder, int lvl) throws Exception {
		logger.info("BoxAccessService.doUploadSubDirs start......");
        File file1 = new File(localDir);
        File fileArray1[] = file1.listFiles();
        for (File f: fileArray1) {
	        // フォルダのアップロード
            if(f.isDirectory()) {
				recResult(String.format("%sサブディレクトリー:[%s],BOXアップロード","-".repeat(lvl * 4),f.getName()));
				BoxFolder subSubFolder = doUploadSub(localDir, f.getName(), subFolder, lvl + 1);
				logger.info(String.format("Directory uploaded, LocalDir:[%s], SubDir:[%s], LinkUrl:[%s]",
				    localDir, f.getName(), "TODO: get SubFolder's URL"));
				recResult(String.format("%sLocal Directory[%s] upload succeeded.", "-".repeat(lvl * 4), f.getName()));
            }
        }
		logger.info("BoxAccessService.doUploadSubDirs finish......");
		return;
	}

	BoxFolder createBoxFolder(BoxFolder folder, String localSubDir, int lvl) throws Exception {
		logger.info("BoxAccessService.createBoxFolder start......");
		BoxFolder.Info folderInfo = null;
		BoxFolder subFolder = null;
		try {
			folderInfo = folder.createFolder(localSubDir);
			subFolder = folderInfo.getResource();
		} catch (Exception ex) {
            if (ex instanceof BoxAPIResponseException || ex instanceof BoxAPIException) {
				BoxAPIException baEx = (BoxAPIException)ex;
				logger.debug("BoxAPIResponseException/BoxAPIException occurred in create box folder:[" + ex + "][" + baEx.getResponseCode() + "]");
				if (baEx.getResponseCode() == 409) {
					logger.debug("Box Folder alread existed. Skip or Continue.");
					switch (boxFolderExistProc) {
						case "SKIP":
							//スキップ、当該フォルダ全体アップロードしない
							logger.info("----------------------BOXフォルダー存在・スキップ");
							recResult(String.format("%sBOXフォルダー存在・スキップ","-".repeat(lvl * 4)));
							return null;
						case "CONT":
							//継続、当該フォルダそのまま利用しアップロードする
							logger.info("----------------------BOXフォルダー存在・そのまま利用");
							recResult(String.format("%sBOXフォルダー存在・そのまま利用","-".repeat(lvl * 4)));
							Iterable<BoxItem.Info> fldItems = folder.getChildren();
							BoxFolder.Info bii = (BoxFolder.Info)existInFolder(fldItems, "folder", localSubDir);
							subFolder = bii.getResource();
							return subFolder;
						case "STOP":
							//ストップ、処理を中止する
							logger.info("----------------------BOXフォルダー存在・ストップ");
							recResult(String.format("%sBOXフォルダー存在・ストップ","-".repeat(lvl * 4)));
							//エラーを再発生させる
							throw ex;
					}
				} else {
					logger.debug("Unknown BoxAPIResponseException/BoxAPIException. Stop processing.");
					//エラーを再発生させる
					throw ex;
				}
			} else {
				logger.debug("Exception occurred in create box folder:[" + ex + "]. Stop processing.");
				//エラーを再発生させる
				throw ex;
			}
		}
		logger.info("BoxAccessService.createBoxFolder finish......");
		return subFolder;
	}

	BoxFile.Info uploadBoxFile(BoxFolder subFolder, FileInputStream input, String fName, long fsize, int lvl) throws Exception {
		logger.info("BoxAccessService.uploadBoxFile start......");
		BoxFile.Info fileInfo = null;
		Iterable<BoxItem.Info> fldItems = null;
		try {
			if (fsize < CNT_LARGE_FILE_SIZE) {
				fileInfo = subFolder.uploadFile(input, fName);
			} else {
				fileInfo = subFolder.uploadLargeFile(input, fName, fsize);
			}
		} catch (Exception ex) {
            if (ex instanceof BoxAPIResponseException || ex instanceof BoxAPIException) {
				BoxAPIException baEx = (BoxAPIException)ex;
				logger.debug("BoxAPIResponseException/BoxAPIException occurred in upload box file:[" + ex + "][" + baEx.getResponseCode() + "]");
				if (baEx.getResponseCode() == 409) {
					logger.debug("Box file alread existed. Skip or Continue.");
					switch (boxFileExistProc) {
						case "SKIP":
							//スキップ、なにもしない
							logger.info("----------------------BOXファイル存在・スキップ");
							recResult(String.format("%sBOXファイル存在・スキップ","-".repeat(lvl * 4)));
							fldItems = subFolder.getChildren();
							fileInfo = (BoxFile.Info)existInFolder(fldItems, "file", fName);
							return fileInfo;
						case "CONT":
							//継続、なにもしない
							logger.info("----------------------BOXファイル存在・継続");
							recResult(String.format("%sBOXファイル存在・継続","-".repeat(lvl * 4)));
							fldItems = subFolder.getChildren();
							fileInfo = (BoxFile.Info)existInFolder(fldItems, "file", fName);
							return fileInfo;
						case "STOP":
							//ストップ、処理を中止する
							logger.info("----------------------BOXファイル存在・ストップ");
							recResult(String.format("%sBOXファイル存在・ストップ","-".repeat(lvl * 4)));
							//エラーを再発生させる
							throw ex;
					}
				} else {
					logger.debug("Unknown BoxAPIResponseException/BoxAPIException. Stop processing.");
					//エラーを再発生させる
					throw ex;
				}
			} else {
				logger.debug("Exception occurred in upload box file:[" + ex + "]. Stop processing.");
				//エラーを再発生させる
				throw ex;
			}
		}
		logger.info("BoxAccessService.uploadBoxFile finish......");
		return fileInfo;
	}

	BoxItem.Info existInFolder(Iterable<BoxItem.Info> fldItems, String itemType, String itemName) {
		for (BoxItem.Info bi : fldItems) {
			logger.info(String.format("BoxItem.Info Type:[%s], Name:[%s]", bi.getType(), bi.getName()));
			if (itemType.equals(bi.getType()) && itemName.equals(bi.getName())) {
				return bi;
			}
		}
		return null;
	}

	boolean existInDir(String localDocDir, String localSubDir) {
		String strDir;
		if ("".equals(localSubDir)) {
			strDir = localDocDir;
		} else {
			strDir = localDocDir + "//" + localSubDir;
		}
        Path path1 = Paths.get(strDir);
        return Files.exists(path1);
	}

	boolean chkUploadFile(String fileName, String extList) {
		String ext;
		boolean ret;
		ext = getFileExtension(fileName);
		ext = "[" + ext + "]";
		ret = extList.indexOf(ext) >= 0;
		return ret;
	}

	private String getFileExtension(String fileName) {
		int lastIndexOf = fileName.lastIndexOf(".");
		if (lastIndexOf == -1) {
			return ""; // empty extension
		} else {
			return fileName.substring(lastIndexOf + 1);
		}
	}	
}
