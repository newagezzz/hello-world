package jp.co.nri.BoxBoot.common;

import java.time.LocalDate;
import java.util.List;

public class Upload { 
    public String taskName; 
    public List<UploadSetting> uploadSettings; 

    //getter, setterは必ず書く。書かないとエラーになる。
    public void setTaskName(String taskName) {
      this.taskName = taskName;
    }
    public String getTaskName() {
      return this.taskName;
    }

    public void setUploadSettings(List<UploadSetting> uploadSettings) {
      this.uploadSettings = uploadSettings;
    }
    public List<UploadSetting> getUploadSettings() {
      return this.uploadSettings;
    }
} 
