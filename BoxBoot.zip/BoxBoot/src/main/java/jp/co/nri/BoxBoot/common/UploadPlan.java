package jp.co.nri.BoxBoot.common;

import java.time.LocalDate;
import java.util.List;

public class UploadPlan { 
    public String localSubDir; 
    public String uploadDate; 
    //getter, setter 
    public void setLocalSubDir(String localSubDir) {
        this.localSubDir = localSubDir;
    }
    public String getLocalSubDir() {
        return this.localSubDir;
    }
    public void setUploadDate(String uploadDate) {
        this.uploadDate = uploadDate;
    }
    public String getUploadDate() {
        return this.uploadDate;
    }
    public boolean chkUploadToday(String todayStrg, boolean uploadTodayOnly) {
        if (!uploadTodayOnly) {
            return true;
        }
        if (todayStrg.equals(uploadDate)  || "9999/99/99".equals(uploadDate)) {
            return true;
        }
        return false;
    }
}

